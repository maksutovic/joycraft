# 0.7.8

**Component:** _TODO: describe what this project is_ | **Stack:** node

---

## Behavioral Boundaries

### ALWAYS
- Run tests and type-check before committing
- Run tests before implementing new features -- confirm they fail first, then implement until they pass
- Use `verb: concise message` format for commits
- Commit after completing each discrete task (atomic commits)
- Stage specific files by name (not `git add -A` or `git add .`)
- Read `docs/context/` before making infrastructure or config changes
- Follow existing code patterns and style

### ASK FIRST
- Pushing to remote
- Creating or merging pull requests
- Adding new dependencies
- Modifying database schema or data models
- Changing authentication or authorization flows
- Any destructive git operation (force-push, reset --hard, branch deletion)

### NEVER
- Push directly to main/master without approval
- Commit .env files, secrets, or credentials
- Use --no-verify to skip hooks
- Amend commits that have been pushed
- Skip type-checking or linting
- Commit code that doesn't build

### External API Safety
- Read official docs and type definitions before writing code against a third-party SDK
- Add third-party SDKs as devDependencies so typecheck runs against real types, not stubs
- Critical integration paths should have a smoke test that validates against the real runtime

## Development Workflow

```bash
# Build
npm run build
# Test
npm run test
```

**Default execution mode:** batch

_How `/joycraft-implement` wraps up after each spec. `joycraft-decompose` reads this line (absent ⇒ `batch`) and recommends a per-spec mode you approve. Modes: `batch` (implement a cluster, wrap once at the end), `checkpoint` (commit + status bump after each spec), `isolated` (fresh context per spec — on Pi, the `joycraft-implement-loop` driver). Change the value above to set your project default._

**Deferred work → `docs/backlog/`.** Ideas and follow-ups you surface mid-sprint but can't take on now go to `docs/backlog/` (one file per item) so the current spec stays focused without losing the thread. Promote an entry to a Feature Brief under `docs/features/<slug>/` when you're ready to build it.

## Architecture

_TODO: Add a brief description of your project's architecture and key directories._

## Key Files

| File | Purpose |
|------|---------|
| _TODO_ | _Add key files and their purposes_ |

## Common Gotchas

_TODO: Add any gotchas, quirks, or non-obvious behaviors that developers should know about._

## Context Map

Keep this file lean — link out, don't inline. Long-form reference docs live in `docs/context/reference/`; this table points to what to read on demand.

| Document | Read it when… |
|----------|---------------|

## Getting Started with Joycraft

This project uses [Joycraft](https://github.com/maksutovic/joycraft) for AI development workflow. Available skills:

| Skill | Purpose |
|-------|---------|
| `/joycraft-setup` | Start here — the first-run door; sets up and assesses your project |
| `/joycraft-tune` | Assess your harness, apply upgrades, see your maturity roadmap |
| `/joycraft-new-feature` | Interview -> Feature Brief -> Atomic Specs |
| `/joycraft-interview` | Lightweight brainstorm — yap about ideas, get a structured summary |
| `/joycraft-decompose` | Break a brief into small, testable specs |
| `/joycraft-session-end` | Capture discoveries, verify, commit |
| `/joycraft-implement-level5` | Experimental — Level 5 autofix loop, holdout scenarios, scenario evolution |

Run `/joycraft-tune` to see where your project stands and what to improve next.

Skill names are shared across tools; only the invocation prefix differs: `/joycraft-*` (Claude Code), `$joycraft-*` (Codex), `/skill:joycraft-*` (Pi).

## Execution Profile

<!-- joycraft:execution-profile -->
- claude: Swarms: decompose no · implement no · model session default · effort session default
- codex: Swarms: decompose no · implement no · model session default · effort session default
- pi: Swarms: decompose no · implement no · model session default · effort session default
- copilot: Swarms: decompose no · implement no · model session default · effort session default
<!-- /joycraft:execution-profile -->
