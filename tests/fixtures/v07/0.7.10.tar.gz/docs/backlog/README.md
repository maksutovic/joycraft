# Backlog

Deferred work lives here — ideas and follow-ups you surface mid-sprint but
can't take on in the current feature. Capturing them keeps the current spec
focused without losing the thread.

- One file per item: `docs/backlog/YYYY-MM-DD-<short-name>.md`.
- Joycraft skills (`/joycraft-interview`, `/joycraft-new-feature`,
  `/joycraft-design`) offer to write entries here — always with your
  confirmation, never automatically.
- Promote an item by turning it into a Feature Brief under
  `docs/features/<slug>/` when you're ready to build it.
